# main.py
from overview_analyzer import OverviewAnalyzer
from behavior_analyzer import BehaviorAnalyzer
from region_analyzer import RegionAnalyzer

file_path = "train.csv"

overview_analyzer = OverviewAnalyzer(file_path)
behavior_analyzer = BehaviorAnalyzer(file_path)
region_analyzer = RegionAnalyzer(file_path)

print("=== Thống kê tổng quan ===")
print("Tổng số khách hàng:", overview_analyzer.total_customers())
print("Tỷ lệ Nam - Nữ (%):", overview_analyzer.gender_ratio())
print("Tuổi trung bình:", overview_analyzer.average_age())
print("Tỷ lệ có bằng lái xe (%):", overview_analyzer.driving_license_ratio())
print("Tỷ lệ từng mua bảo hiểm trước đó (%):", overview_analyzer.previously_insured_ratio())

print("\n=== Hành vi khách hàng ===")
print("Phân bố tuổi xe (%):", behavior_analyzer.vehicle_age_distribution())
print("Tỷ lệ khách hàng từng gặp tổn thất với xe (%):", behavior_analyzer.vehicle_damage_ratio())
print("Tỷ lệ phản hồi đồng ý mua bảo hiểm (%):", behavior_analyzer.response_ratio())

print("\n=== Phân tích theo khu vực ===")
print("Top khu vực có nhiều khách hàng nhất (%):", region_analyzer.top_regions_by_customers())
print("Khu vực có tỷ lệ phản hồi cao nhất (%):", region_analyzer.region_with_highest_response())