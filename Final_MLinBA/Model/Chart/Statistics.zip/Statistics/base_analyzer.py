from data_loader import DataLoader

class BaseAnalyzer:
    def __init__(self, file_path):
        self.loader = DataLoader(file_path)
        self.df = self.loader.get_data()

    def check_data_empty(self):
        if self.df.empty:
            raise ValueError("Dữ liệu rỗng! Vui lòng kiểm tra lại file CSV.")