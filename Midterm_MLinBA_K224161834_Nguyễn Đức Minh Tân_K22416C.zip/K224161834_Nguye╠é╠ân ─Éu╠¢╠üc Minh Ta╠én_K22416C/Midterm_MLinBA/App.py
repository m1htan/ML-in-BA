from PyQt6.QtWidgets import QApplication, QMainWindow

from MLinBA.Midterm_MLinBA.UI.LoginWindowExt import LoginWindowExt

app=QApplication([])
qmainWindow = QMainWindow()
myui = LoginWindowExt()
myui.show()
app.exec()