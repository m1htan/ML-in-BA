import self

print(self.conn)  # Kiểm tra nếu bị None
