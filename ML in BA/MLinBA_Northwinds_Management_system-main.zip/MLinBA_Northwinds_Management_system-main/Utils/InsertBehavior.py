from enum import Enum


class InsertBehavior(Enum):
    INSERT_FIRST = 0
    INSERT_LAST = 1
    INSERT_ABOVE = 2
    INSERT_BELOW = 33