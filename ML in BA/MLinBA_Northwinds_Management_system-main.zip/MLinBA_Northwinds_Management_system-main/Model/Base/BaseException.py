class InvalidTableNameError(Exception):
    pass